<?php

class DivisionByZeroError extends Error
{
}
