| Q             | A
| ------------- | ---
| Branch?       | "master" for new features / 2.3, 2.7, 2.8 or 3.0 for fixes
| Bug fix?      | yes/no
| New feature?  | yes/no
| BC breaks?    | yes/no
| Deprecations? | yes/no
| Tests pass?   | yes/no
| Fixed tickets | comma-separated list of tickets fixed by the PR, if any
| License       | MIT
| Doc PR        | reference to the documentation PR, if any
