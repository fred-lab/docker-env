CHANGELOG
=========

2.3.0
-----

 * First introduction of `Symfony\Bridge\ProxyManager`
